# -*- coding: utf-8 -*-
import bpy
from . import exporter
from . import backup

class AEGON_PT_panel(bpy.types.Panel):
    bl_label = "Aegon Texture Exporter"
    bl_idname = "AEGON_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Aegon Tools"
    def draw(self, context):
        s = context.scene
        l = self.layout
        box = l.box(); box.label(text="Export Root"); box.prop(s, "aegon_export_root", text="")
        box = l.box(); box.label(text="Scope")
        row = box.row(align=True); row.prop(s, "aegon_only_selected"); row.prop(s, "aegon_include_objname")
        row = box.row(align=True); row.prop(s, "aegon_include_rawname")
        box = l.box(); box.label(text="Maps")
        row = box.row(align=True); row.prop(s, "aegon_map_base"); row.prop(s, "aegon_map_normal")
        row = box.row(align=True); row.prop(s, "aegon_map_rough"); row.prop(s, "aegon_map_spec")
        row = box.row(align=True); row.prop(s, "aegon_map_ao"); row.prop(s, "aegon_map_metal")
        row = box.row(align=True); row.prop(s, "aegon_map_height")
        box = l.box(); box.label(text="Quality")
        row = box.row(align=True); row.prop(s, "aegon_resolution"); row.prop(s, "aegon_mipmap"); row.prop(s, "aegon_threads")
        box = l.box(); box.label(text="Run Export")
        row = box.row(align=True); row.operator("aegon.export_scene", icon="EXPORT"); row.operator("aegon.clear_seen_raw", icon="TRASH")
        box = l.box(); box.label(text="Process External Folder")
        box.prop(s, "aegon_external_folder", text="Folder")
        row = box.row(align=True); row.operator("aegon.process_external", icon="FILE_FOLDER")
        box = l.box(); box.label(text="Backup / Zip")
        row = box.row(align=True); row.operator("aegon.make_backup", icon="FILE_ARCHIVE"); row.operator("aegon.delete_backup", icon="TRASH")
        box.label(text=f"Backup size: {backup.readable_backup_size(context)}")

def register():
    from bpy.props import StringProperty, BoolProperty, EnumProperty, IntProperty
    bpy.utils.register_class(AEGON_PT_panel)
    bpy.types.Scene.aegon_export_root = StringProperty(name="Export Root", subtype='DIR_PATH', default="")
    bpy.types.Scene.aegon_only_selected = BoolProperty(name="Only Selected", default=True)
    bpy.types.Scene.aegon_include_objname = BoolProperty(name="Include Object Name", default=False)
    bpy.types.Scene.aegon_include_rawname = BoolProperty(name="Include Raw Name", default=False)
    bpy.types.Scene.aegon_map_base = BoolProperty(name="Base/Diffuse", default=True)
    bpy.types.Scene.aegon_map_normal = BoolProperty(name="Normal", default=True)
    bpy.types.Scene.aegon_map_rough = BoolProperty(name="Roughness", default=True)
    bpy.types.Scene.aegon_map_spec = BoolProperty(name="Specular", default=True)
    bpy.types.Scene.aegon_map_ao = BoolProperty(name="AO", default=False)
    bpy.types.Scene.aegon_map_metal = BoolProperty(name="Metallic", default=False)
    bpy.types.Scene.aegon_map_height = BoolProperty(name="Height/Disp", default=False)
    bpy.types.Scene.aegon_resolution = EnumProperty(name="Resolution", items=[("512","512",""),("1024","1024",""),("2048","2048","")], default="1024")
    bpy.types.Scene.aegon_mipmap = BoolProperty(name="Mipmap", default=True)
    bpy.types.Scene.aegon_threads = IntProperty(name="Threads", default=4, min=1, max=32)
    bpy.types.Scene.aegon_external_folder = StringProperty(name="External Folder", subtype='DIR_PATH', default="")
    exporter.register(); backup.register()

def unregister():
    backup.unregister(); exporter.unregister()
    del bpy.types.Scene.aegon_external_folder
    del bpy.types.Scene.aegon_threads
    del bpy.types.Scene.aegon_mipmap
    del bpy.types.Scene.aegon_resolution
    del bpy.types.Scene.aegon_map_height
    del bpy.types.Scene.aegon_map_metal
    del bpy.types.Scene.aegon_map_ao
    del bpy.types.Scene.aegon_map_spec
    del bpy.types.Scene.aegon_map_rough
    del bpy.types.Scene.aegon_map_normal
    del bpy.types.Scene.aegon_map_base
    del bpy.types.Scene.aegon_include_rawname
    del bpy.types.Scene.aegon_include_objname
    del bpy.types.Scene.aegon_only_selected
    del bpy.types.Scene.aegon_export_root
    bpy.utils.unregister_class(AEGON_PT_panel)
