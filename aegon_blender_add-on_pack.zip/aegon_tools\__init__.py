# -*- coding: utf-8 -*-
bl_info = {
    "name": "Aegon Tools",
    "author": "Aegon / Aegon Design",
    "version": (1, 0, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar / UV Menu (UV tools)",
    "description": "Tek paket: Material Optimizer, UV Tools, Texture & UV Fixer, Poly Optimizer, Boolean System PRO, Texture Exporter (DDS).",
    "category": "Object",
}

from . import (
    material_optimizer,
    uv_tools,
    texture_uv_fixer,
    poly_optimizer,
    boolean_system,
    texture_exporter,
)


def register():
    material_optimizer.register()
    uv_tools.register()
    texture_uv_fixer.register()
    poly_optimizer.register()
    boolean_system.register()
    texture_exporter.register()


def unregister():
    texture_exporter.unregister()
    boolean_system.unregister()
    poly_optimizer.unregister()
    texture_uv_fixer.unregister()
    uv_tools.unregister()
    material_optimizer.unregister()
