# -*- coding: utf-8 -*-
import bpy, os, shutil, subprocess, tempfile, re, json, threading
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

# ---- Kategori anahtar kelimeleri (isim analizinde kullanılır) ----
KEYWORDS = {
    "normal": ["normal", "nrm", "_n", "norm"],
    "rough":  ["rough", "roughness", "_r"],
    "metal":  ["metal", "metallic", "metalness", "_m"],
    "spec":   ["spec", "specular", "_s"],
    "height": ["height", "disp", "displace", "displacement", "_h"],
    "ao":     ["ao", "ambientocclusion", "ambient_occlusion", "occlusion"],
    "base":   ["base", "albedo", "diffuse", "color", "basecolor"],
}

# Klasör adları
CATEGORY_FOLDERS = {
    "base":"base","normal":"normal","rough":"rough",
    "spec":"spec","height":"height","ao":"ao","metal":"metal"
}

# texconv formatları
DDS_FORMATS = {
    "base":   ["-f","BC1_UNORM","-srgb"],
    "normal": ["-f","BC5_UNORM"],
    "rough":  ["-f","BC4_UNORM"],
    "spec":   ["-f","BC4_UNORM"],
    "height": ["-f","BC4_UNORM"],
    "ao":     ["-f","BC4_UNORM"],
    "metal":  ["-f","BC4_UNORM"],
}

# ----------------- Yardımcılar -----------------
def sanitize(name: str) -> str:
    n = name.strip().lower().replace(" ", "_")
    n = re.sub(r'[^a-z0-9._-]+', "_", n)
    n = re.sub(r'_+', "_", n)
    return n

def addon_dir() -> Path: return Path(__file__).resolve().parent

def resolve_export_root(context) -> Path:
    path = context.scene.aegon_export_root
    return Path(bpy.path.abspath(path)) if path else Path(bpy.path.abspath("//assets"))

def log_path_for(root: Path) -> Path: return root / "aegon_log.json"

def load_log(log_path: Path) -> dict:
    if log_path.exists():
        try:
            with open(log_path, "r", encoding="utf-8") as f:
                d = json.load(f)
                if isinstance(d, dict):
                    d.setdefault("next_index", 1); d.setdefault("seen_raw", [])
                    return d
        except: pass
    return {"next_index": 1, "seen_raw": []}

def save_log(log_path: Path, data: dict):
    with open(log_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def find_texconv() -> str | None:
    cand = addon_dir() / "bin" / "texconv.exe"
    if cand.exists(): return str(cand)
    if shutil.which("texconv"): return "texconv"
    return None

# ----------------- Görsel yol/anahtar -----------------
def image_abspath(img: bpy.types.Image) -> str:
    try:
        if img.filepath:
            p = bpy.path.abspath(img.filepath)
            if p and os.path.exists(p): return p
    except: pass
    return ""

def image_raw_key(img: bpy.types.Image) -> str:
    p = image_abspath(img)
    if p: return os.path.abspath(p)
    w, h = getattr(img, "size", (0, 0))
    return f"packed::{img.name}::{w}x{h}"

# ----------------- İsimden kategori tahmini -----------------
def guess_category_from_name(name: str) -> str | None:
    nm = name.lower()
    # daha spesifik olanları önce dene
    for cat in ["normal","rough","metal","spec","height","ao","base"]:
        words = KEYWORDS.get(cat, [])
        if any(w in nm for w in words): return cat
    return None

# ----------------- Node grafından kategori tespiti -----------------
def map_socket_to_category(socket_name: str) -> str | None:
    s = (socket_name or "").strip().lower()
    if "base color" in s: return "base"
    if s == "color": return None  # tek başına bilgi değil
    if "normal" in s: return "normal"
    if "roughness" in s: return "rough"
    if "specular" in s: return "spec"
    if "metallic" in s: return "metal"
    if "height" in s: return "height"
    if "displacement" in s: return "height"
    if s == "ao" or "ambient occlusion" in s: return "ao"
    return None

def node_category_via_graph(img_node: bpy.types.Node, max_depth: int = 5) -> str | None:
    """Image Texture node'dan başlayıp ileri doğru linkleri gezerek
       Principled BSDF / Normal Map / Displacement gibi düğümlere bakar."""
    if img_node.type != 'TEX_IMAGE': return None
    visited_nodes = set()
    queue = [(img_node, 0)]

    while queue:
        node, depth = queue.pop(0)
        if node is None or node in visited_nodes or depth > max_depth: 
            continue
        visited_nodes.add(node)

        # NORMAL_MAP ise direkt normal kabul
        if node.type == 'NORMAL_MAP':
            return "normal"

        # Principled veya Material Output gibi düğümler için giriş soketi adları önemlidir
        if node.type in {'BSDF_PRINCIPLED', 'OUTPUT_MATERIAL', 'DISPLACEMENT'}:
            # bu düğüme gelen linkleri inceleyerek hangi girişe bağlandığımıza bakarız
            for inp in node.inputs:
                for link in inp.links:
                    if link.from_node in visited_nodes:  # img'den gelen zincirin parçası olabilir
                        cat = map_socket_to_category(inp.name)
                        if cat: return cat

        # mevcut node'un çıkışlarından devam et
        for out in node.outputs:
            for link in out.links:
                # hedef soket adı doğrudan ipucu olabilir
                cat = map_socket_to_category(link.to_socket.name)
                if cat:
                    # Eğer doğrudan Principled/Output'a gidiyorsa daha güvenilir
                    if link.to_node.type in {'BSDF_PRINCIPLED','OUTPUT_MATERIAL','DISPLACEMENT','NORMAL_MAP'}:
                        return cat
                    # Değilse yine de devam edip doğrulamaya çalış
                    tentative = cat
                else:
                    tentative = None

                # özel durum: Normal Map zinciri
                if link.to_node.type == 'NORMAL_MAP':
                    return "normal"

                # sıradaki node'u kuyruğa ekle
                queue.append((link.to_node, depth + 1))

    return None

def determine_category(node: bpy.types.Node) -> str | None:
    """Önce node grafı, sonra isim analizi ile kategori belirle."""
    if node.type != 'TEX_IMAGE' or not node.image:
        return None
    # 1) graf analizi
    cat = node_category_via_graph(node)
    if cat: return cat
    # 2) isim analizi (image adı)
    cat = guess_category_from_name(node.image.name)
    if cat: return cat
    # 3) dosya adı (yol)
    p = image_abspath(node.image)
    if p:
        cat = guess_category_from_name(os.path.basename(p))
        if cat: return cat
    return None

# ----------------- İsimlendirme -----------------
def make_output_name(idx: int, cat: str, objname: str | None, rawname: str | None, include_obj: bool, include_raw: bool) -> str:
    parts = [f"aegon_{idx}"]
    if include_obj and objname: parts.append(sanitize(objname))
    if include_raw and rawname: parts.append(sanitize(rawname))
    parts.append(cat)
    return "_".join(parts) + ".dds"

# ----------------- Geçici yazma -----------------
def write_temp_raw(img: bpy.types.Image, tmp_dir: Path) -> Path | None:
    src = image_abspath(img)
    if src:
        ext = os.path.splitext(src)[1] or ".png"
        dst = tmp_dir / f"src{ext}"
        try:
            shutil.copy2(src, dst); return dst
        except Exception: return None
    dst = tmp_dir / "src.png"
    try:
        img.filepath_raw = str(dst); img.file_format = 'PNG'; img.save(); return dst
    except Exception:
        try: img.save_render(str(dst)); return dst
        except Exception: return None

def tex_is_dds(path: str) -> bool: return path.lower().endswith(".dds")

def convert_with_texconv(texconv: str, in_path: Path, out_path: Path, cat: str, res: int, mipmap: bool) -> bool:
    out_dir = out_path.parent; out_dir.mkdir(parents=True, exist_ok=True)
    args = [texconv, "-y", "-o", str(out_dir), "-w", str(res), "-h", str(res)]
    if not mipmap: args += ["-m", "1"]
    args += DDS_FORMATS.get(cat, ["-f","BC1_UNORM"]); args.append(str(in_path))
    try:
        subprocess.run(args, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        produced = None
        for p in out_dir.glob("*.dds"):
            if produced is None or p.stat().st_mtime > produced.stat().st_mtime: produced = p
        if produced is None: return False
        if produced.resolve() != out_path.resolve():
            if out_path.exists(): out_path.unlink()
            produced.rename(out_path)
        return True
    except Exception:
        return False

# ----------------- Task toplayıcılar -----------------
def _wanted_set(scene) -> set:
    w = set()
    if scene.aegon_map_base: w.add("base")
    if scene.aegon_map_normal: w.add("normal")
    if scene.aegon_map_rough: w.add("rough")
    if scene.aegon_map_spec: w.add("spec")
    if scene.aegon_map_ao: w.add("ao")
    if scene.aegon_map_metal: w.add("metal")
    if scene.aegon_map_height: w.add("height")
    return w

def gather_scene_tasks(context):
    s = context.scene
    wanted = _wanted_set(s)
    objs = context.selected_objects if s.aegon_only_selected else list(bpy.data.objects)
    images_info, seen_img = [], set()
    for obj in objs:
        if obj.type != 'MESH': continue
        for slot in obj.material_slots:
            mat = slot.material
            if not mat or not mat.use_nodes: continue
            for node in mat.node_tree.nodes:
                if node.type != 'TEX_IMAGE': continue
                img = node.image
                if not img: continue
                rawk = image_raw_key(img)
                if rawk in seen_img:  # aynı image birden fazla yerde kullanılsa da bir kez
                    continue
                cat = determine_category(node)
                if not cat or cat not in wanted:
                    continue
                seen_img.add(rawk)
                images_info.append({
                    "img_name": img.name,
                    "obj_name": obj.name,
                    "category": cat,
                    "raw_key": rawk,
                    "img_ref": img
                })
    return images_info

def gather_external_tasks(context):
    s = context.scene
    folder = s.aegon_external_folder
    if not folder or not os.path.isdir(bpy.path.abspath(folder)): return []
    folder = bpy.path.abspath(folder)
    wanted = _wanted_set(s)
    tasks = []
    for root, dirs, files in os.walk(folder):
        for fn in files:
            low = fn.lower()
            if not any(low.endswith(ext) for ext in [".png",".jpg",".jpeg",".tga",".bmp",".tif",".tiff",".exr",".hdr",".dds"]):
                continue
            cat = guess_category_from_name(low)
            if not cat or cat not in wanted: 
                continue
            tasks.append({
                "path": os.path.join(root, fn),
                "category": cat,
                "raw_key": os.path.abspath(os.path.join(root, fn)),
                "img_name": fn,
                "obj_name": ""
            })
    return tasks

# ----------------- İşleme -----------------
def process_task(texconv, task, export_root: Path, log_data: dict, s) -> bool:
    idx = log_data["next_index"]
    objn = task.get("obj_name") or None
    rawn = task.get("img_name") or None

    # Klasör sadece gerekli olduğunda yarat
    out_folder = export_root / CATEGORY_FOLDERS[task["category"]]
    out_name = make_output_name(idx, task["category"], objn, rawn, s.aegon_include_objname, s.aegon_include_rawname)
    out_path = out_folder / out_name

    in_path, tmp_dir = None, None
    if "path" in task and task["path"]:
        in_path = Path(task["path"])
    else:
        img = task.get("img_ref")
        tmp_dir = Path(tempfile.mkdtemp(prefix="aegon_raw_"))
        tmp = write_temp_raw(img, tmp_dir)
        if tmp is None:
            if tmp_dir: shutil.rmtree(tmp_dir, ignore_errors=True)
            return False
        in_path = tmp

    if task["raw_key"] in log_data["seen_raw"]:
        if tmp_dir: shutil.rmtree(tmp_dir, ignore_errors=True)
        return True

    ok = False
    try:
        if tex_is_dds(str(in_path)):
            out_folder.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(in_path), str(out_path)); ok = True
        else:
            res = int(s.aegon_resolution)
            ok = convert_with_texconv(texconv, Path(in_path), out_path, task["category"], res, s.aegon_mipmap)
    finally:
        if tmp_dir: shutil.rmtree(tmp_dir, ignore_errors=True)

    if ok:
        log_data["seen_raw"].append(task["raw_key"])
        log_data["next_index"] = idx + 1
    return ok

# ----------------- Operatörler -----------------
class AEGON_OT_export_scene(bpy.types.Operator):
    bl_idname = "aegon.export_scene"; bl_label = "Export Scene to DDS"; bl_options = {'REGISTER'}
    def execute(self, context):
        export_root = resolve_export_root(context)
        export_root.mkdir(parents=True, exist_ok=True)  # sadece kök klasör
        # ALT KLASÖR ÖNCEDEN OLUŞTURULMUYOR!

        tmp_blend = export_root / "aegon_export_temp.blend"
        try:
            bpy.ops.wm.save_as_mainfile(filepath=str(tmp_blend))
        except Exception:
            try: bpy.ops.wm.save_mainfile()
            except Exception: pass

        log_file = log_path_for(export_root); log_data = load_log(log_file)
        tasks = gather_scene_tasks(context)
        if not tasks:
            self.report({'WARNING'}, "No eligible images found."); return {'CANCELLED'}

        texconv = find_texconv()
        if not texconv:
            self.report({'ERROR'}, "texconv.exe not found. Put it in addon_folder/bin/texconv.exe or add to PATH."); return {'CANCELLED'}

        s = context.scene; count_ok = 0; lock = threading.Lock()
        def run_task(t):
            nonlocal count_ok
            ok = process_task(texconv, t, export_root, log_data, s)
            with lock:
                if ok: count_ok += 1

        with ThreadPoolExecutor(max_workers=max(1, s.aegon_threads)) as ex:
            ex.map(run_task, tasks)

        save_log(log_file, log_data)

        try:
            if tmp_blend.exists(): tmp_blend.unlink()
        except Exception: pass

        self.report({'INFO'}, f"Aegon ♥ Exported: {count_ok} DDS")
        try:
            if os.name == "nt": os.startfile(str(export_root))
        except Exception: pass
        return {'FINISHED'}

class AEGON_OT_clear_seen(bpy.types.Operator):
    bl_idname = "aegon.clear_seen_raw"; bl_label = "Reset Seen (Allow Re-Export)"; bl_options = {'REGISTER'}
    def execute(self, context):
        root = resolve_export_root(context); lp = log_path_for(root); data = load_log(lp); data["seen_raw"] = []; save_log(lp, data)
        self.report({'INFO'}, "Seen list cleared. Numbering preserved."); return {'FINISHED'}

class AEGON_OT_process_external(bpy.types.Operator):
    bl_idname = "aegon.process_external"; bl_label = "Process External Folder → DDS"; bl_options = {'REGISTER'}
    def execute(self, context):
        export_root = resolve_export_root(context)
        export_root.mkdir(parents=True, exist_ok=True)  # sadece kök
        # ALT KLASÖR ÖNCEDEN OLUŞTURULMUYOR!

        log_file = log_path_for(export_root); log_data = load_log(log_file)
        tasks = gather_external_tasks(context)
        if not tasks:
            self.report({'WARNING'}, "No eligible textures found in external folder."); return {'CANCELLED'}

        texconv = find_texconv()
        if not texconv:
            self.report({'ERROR'}, "texconv.exe not found. Put it in addon_folder/bin/texconv.exe or add to PATH."); return {'CANCELLED'}

        s = context.scene; count_ok = 0; lock = threading.Lock()
        def run_task(t):
            nonlocal count_ok
            ok = process_task(texconv, t, export_root, log_data, s)
            with lock:
                if ok: count_ok += 1

        with ThreadPoolExecutor(max_workers=max(1, s.aegon_threads)) as ex:
            ex.map(run_task, tasks)

        save_log(log_file, log_data)
        self.report({'INFO'}, f"Aegon ♥ External processed: {count_ok} DDS")
        try:
            if os.name == "nt": os.startfile(str(export_root))
        except Exception: pass
        return {'FINISHED'}

def register():
    bpy.utils.register_class(AEGON_OT_export_scene)
    bpy.utils.register_class(AEGON_OT_clear_seen)
    bpy.utils.register_class(AEGON_OT_process_external)

def unregister():
    bpy.utils.unregister_class(AEGON_OT_process_external)
    bpy.utils.unregister_class(AEGON_OT_clear_seen)
    bpy.utils.unregister_class(AEGON_OT_export_scene)
