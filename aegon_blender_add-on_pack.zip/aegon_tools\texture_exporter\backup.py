# -*- coding: utf-8 -*-
import bpy, os, zipfile
from pathlib import Path
from .exporter import resolve_export_root, log_path_for

def backup_path(root: Path) -> Path: return root / "aegon_backup.zip"

def calc_backup_size(root: Path) -> int:
    zp = backup_path(root)
    return zp.stat().st_size if zp.exists() else 0

def readable_backup_size(context) -> str:
    root = resolve_export_root(context); sz = calc_backup_size(root)
    if sz == 0: return "No backup zip"
    for unit in ["B","KB","MB","GB","TB"]:
        if sz < 1024: return f"{sz:.1f} {unit}"
        sz /= 1024.0
    return f"{sz:.1f} PB"

class AEGON_OT_make_backup(bpy.types.Operator):
    bl_idname = "aegon.make_backup"; bl_label = "Make Backup Zip"; bl_options = {'REGISTER'}
    def execute(self, context):
        root = resolve_export_root(context); zp = backup_path(root); logp = log_path_for(root)
        with zipfile.ZipFile(zp, "w", compression=zipfile.ZIP_DEFLATED) as z:
            if logp.exists(): z.write(logp, arcname=logp.name)
            for sub in root.iterdir():
                if sub.is_dir():
                    for p in sub.rglob("*.dds"):
                        z.write(p, arcname=str(Path(sub.name) / p.name))
        self.report({'INFO'}, f"Backup created: {zp.name}"); return {'FINISHED'}

class AEGON_OT_delete_backup(bpy.types.Operator):
    bl_idname = "aegon.delete_backup"; bl_label = "Delete Backup Zip"; bl_options = {'REGISTER'}
    def execute(self, context):
        zp = backup_path(resolve_export_root(context))
        if zp.exists(): zp.unlink(); self.report({'INFO'}, "Backup deleted.")
        else: self.report({'INFO'}, "No backup zip to delete.")
        return {'FINISHED'}

def register():
    bpy.utils.register_class(AEGON_OT_make_backup)
    bpy.utils.register_class(AEGON_OT_delete_backup)

def unregister():
    bpy.utils.unregister_class(AEGON_OT_delete_backup)
    bpy.utils.unregister_class(AEGON_OT_make_backup)
